    let gridConfig = {
        settings: {
            gridSelector: '#grid',
            svgSelector: '#gridSvg',
            cellSize: 40,
            borderSize: 1,
            borderColor: 'gray',
            verticesWeight: 1
        }
    }

    export default gridConfig