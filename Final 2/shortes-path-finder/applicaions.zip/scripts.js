    import Grid from './applicaions/grid/Grid.class.js'
    import gridConfig from './applicaions/config/grid.config.js'

    const grid = new Grid(gridConfig)

    grid.build()
    grid.draw()